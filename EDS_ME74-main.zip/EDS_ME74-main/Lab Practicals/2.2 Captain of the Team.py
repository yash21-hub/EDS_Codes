heights = list(map(int,input().split(" ")))
captain = max(heights)
print(captain)